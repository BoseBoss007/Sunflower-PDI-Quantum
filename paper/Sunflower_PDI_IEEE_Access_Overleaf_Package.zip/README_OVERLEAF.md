# IEEE Access Overleaf Submission & Editing Package

### Project Title:
**Quantum-Enhanced Vision Framework for Sunflower Pollen Deficiency Estimation: A Comparative Benchmark of Classical Baselines and Variational Quantum State Encodings**

### Authors:
- **Ramit Bose** (Student Member, IEEE), Vellore Institute of Technology
- **Samriddhi Sarkar** (Senior Member, IEEE), Vellore Institute of Technology

---

### How to Use on Overleaf:
1. Go to [Overleaf.com](https://www.overleaf.com) and click **"New Project" -> "Upload Project"**.
2. Select the `Sunflower_PDI_IEEE_Access_Overleaf_Package.zip` file.
3. Overleaf will automatically extract the project and open `main.tex`.
4. Ensure the Overleaf compiler setting is set to **pdfLaTeX** (default).
5. Click **"Recompile"** to compile the document.

### Package Contents:
- `main.tex`: Root LaTeX manuscript file (exact duplicate of `Sunflower_PDI_IEEE_Access_Manuscript.tex` for automatic Overleaf root detection).
- `Sunflower_PDI_IEEE_Access_Manuscript.tex`: Standalone named LaTeX manuscript.
- `Sunflower_PDI_IEEE_Access_Manuscript.pdf`: Full 22-page camera-ready reference PDF.
- `figures/`: Subdirectory containing all 33 high-resolution standalone figures (both PNG and vector PDF formats).
- `ieeeaccess.cls`, `IEEEtran.cls`, `IEEEtran.bst`, `spotcolor.sty`: Official IEEE Access LaTeX document classes and bibliography styles.
- `*.pfb`, `*.tfm`, `*.fd`, `*.map`: Official IEEE Access font definition and metric files.
- `author1.png`, `author2.png`, `logo.png`, `bullet.png`: Author photos and IEEE Access iconography.
